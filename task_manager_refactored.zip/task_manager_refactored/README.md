# Менеджер задач

Проект переработан в модульную архитектуру по заданию.

## Структура

```text
project/
├── models/
│   └── task.py
├── storage/
│   └── storage_manager.py
├── ui/
│   └── interface.py
├── manager/
│   └── task_manager.py
├── main.py
└── tasks.json             # создаётся автоматически после первой записи
```

## Классы

- **Task** — модель задачи: `id`, `title`, `description`, `status`, `author`, `created_at`.
  Методы `to_dict()` и `from_dict()` преобразуют объект в словарь и обратно.
- **StorageManager** — загрузка и сохранение JSON, а также операции `add`, `update`, `delete`.
- **Interface** — графический интерфейс Tkinter. Использует классы-обёртки `AppButton`,
  `AppListbox`, `AppEntry`, `AppLabel`.
- **TaskManager** — фасад, содержащий CRUD-методы и метод `run()`.

## Запуск

Требуется Python 3.10+ и Tkinter (обычно входит в стандартную поставку Python).

```bash
python main.py
```

Файл `tasks.json` создаётся автоматически в текущей рабочей директории.

## Проверка

```bash
python -m compileall .\npython -m unittest discover -s tests
```

Для проверки без запуска графического окна можно создать `TaskManager` с отдельным файлом:

```python
from manager.task_manager import TaskManager
from storage.storage_manager import StorageManager

manager = TaskManager(StorageManager("test_tasks.json"))
task = manager.create_task("Проверить CRUD", "Создание задачи", "Ученик")
manager.edit_task(task.id, "CRUD проверен", "Изменение задачи", "Ученик")
manager.toggle_status(task.id)
manager.delete_task(task.id)
```
