"""Точка входа приложения."""
from manager.task_manager import TaskManager


def main():
    TaskManager().run()


if __name__ == "__main__":
    main()
