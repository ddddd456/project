"""Фасад: бизнес-логика приложения и запуск интерфейса."""
import tkinter as tk
from models.task import Task
from storage.storage_manager import StorageManager
from ui.interface import Interface


class TaskManager:
    def __init__(self, storage=None):
        self.storage = storage or StorageManager()

    def get_tasks(self) -> list[Task]:
        return self.storage.load()

    def create_task(self, title, description="", author="") -> Task:
        title = title.strip()
        if not title:
            raise ValueError("Название задачи не может быть пустым.")
        return self.storage.add(Task(title=title, description=description.strip(), author=author.strip()))

    def edit_task(self, task_id, title, description="", author="") -> Task:
        title = title.strip()
        if not title:
            raise ValueError("Название задачи не может быть пустым.")
        return self.storage.update(
            task_id, title=title, description=description.strip(), author=author.strip()
        )

    def delete_task(self, task_id) -> None:
        self.storage.delete(task_id)

    def toggle_status(self, task_id) -> Task:
        task = next((item for item in self.get_tasks() if item.id == task_id), None)
        if task is None:
            raise KeyError(f"Задача с id={task_id} не найдена.")
        return self.storage.update(task_id, status=not task.status)

    def run(self):
        root = tk.Tk()
        Interface(root, self)
        root.mainloop()
