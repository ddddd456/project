"""JSON-хранилище. Класс отвечает только за чтение и запись задач."""
import json
from pathlib import Path
from models.task import Task


class StorageManager:
    def __init__(self, file_path="tasks.json"):
        self.file_path = Path(file_path)

    def load(self) -> list[Task]:
        if not self.file_path.exists():
            return []
        try:
            raw = json.loads(self.file_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            raise ValueError(f"Не удалось прочитать файл задач: {exc}") from exc
        if not isinstance(raw, list):
            raise ValueError("Файл задач должен содержать JSON-массив.")
        return [Task.from_dict(item) for item in raw]

    def save(self, tasks: list[Task]) -> None:
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.file_path.with_suffix(self.file_path.suffix + ".tmp")
        temporary.write_text(
            json.dumps([task.to_dict() for task in tasks], ensure_ascii=False, indent=4),
            encoding="utf-8",
        )
        temporary.replace(self.file_path)

    def add(self, task: Task) -> Task:
        tasks = self.load()
        tasks.append(task)
        self.save(tasks)
        return task

    def update(self, task_id: str, **changes) -> Task:
        tasks = self.load()
        for task in tasks:
            if task.id == task_id:
                for key, value in changes.items():
                    if key in {"title", "description", "author", "status"}:
                        setattr(task, key, value)
                self.save(tasks)
                return task
        raise KeyError(f"Задача с id={task_id} не найдена.")

    def delete(self, task_id: str) -> None:
        tasks = self.load()
        updated = [task for task in tasks if task.id != task_id]
        if len(updated) == len(tasks):
            raise KeyError(f"Задача с id={task_id} не найдена.")
        self.save(updated)
