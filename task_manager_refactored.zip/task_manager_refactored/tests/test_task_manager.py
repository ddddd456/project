import tempfile
import unittest
from pathlib import Path

from manager.task_manager import TaskManager
from storage.storage_manager import StorageManager


class TaskManagerTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.manager = TaskManager(StorageManager(Path(self.temp_dir.name) / "tasks.json"))

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_full_crud_and_json_persistence(self):
        task = self.manager.create_task("Купить тетрадь", "Для учёбы", "Алекс")
        self.assertEqual(len(self.manager.get_tasks()), 1)
        self.manager.edit_task(task.id, "Купить блокнот", "В клетку", "Алекс")
        updated = self.manager.toggle_status(task.id)
        self.assertEqual(updated.title, "Купить блокнот")
        self.assertTrue(updated.status)
        self.manager.delete_task(task.id)
        self.assertEqual(self.manager.get_tasks(), [])

    def test_empty_title_is_rejected(self):
        with self.assertRaises(ValueError):
            self.manager.create_task("   ")


if __name__ == "__main__":
    unittest.main()
