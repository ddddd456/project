"""Графический интерфейс Tkinter. Виджеты вынесены в отдельные классы."""
import tkinter as tk
from tkinter import messagebox, simpledialog
from models.task import Task


class AppLabel(tk.Label):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)


class AppEntry(tk.Entry):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)


class AppButton(tk.Button):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)


class AppListbox(tk.Listbox):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)


class Interface:
    def __init__(self, root, manager):
        self.root = root
        self.manager = manager
        self.tasks = []
        self.root.title("Менеджер задач")
        self.root.geometry("760x480")
        self.root.minsize(600, 360)
        self._build()
        self.show_tasks()

    def _build(self):
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        form = tk.Frame(self.root, padx=12, pady=10)
        form.grid(row=0, column=0, sticky="ew")
        form.columnconfigure(1, weight=1)

        AppLabel(form, text="Название:").grid(row=0, column=0, sticky="w", padx=4, pady=4)
        self.title_entry = AppEntry(form)
        self.title_entry.grid(row=0, column=1, sticky="ew", padx=4, pady=4)

        AppLabel(form, text="Описание:").grid(row=1, column=0, sticky="w", padx=4, pady=4)
        self.description_entry = AppEntry(form)
        self.description_entry.grid(row=1, column=1, sticky="ew", padx=4, pady=4)

        AppLabel(form, text="Автор:").grid(row=2, column=0, sticky="w", padx=4, pady=4)
        self.author_entry = AppEntry(form)
        self.author_entry.grid(row=2, column=1, sticky="ew", padx=4, pady=4)

        actions = tk.Frame(form)
        actions.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        AppButton(actions, text="Добавить", command=self.add_task).pack(side="left", padx=3)
        AppButton(actions, text="Изменить", command=self.edit_task).pack(side="left", padx=3)
        AppButton(actions, text="Удалить", command=self.delete_task).pack(side="left", padx=3)
        AppButton(actions, text="Выполнено / не выполнено", command=self.toggle_status).pack(side="left", padx=3)
        AppButton(actions, text="Обновить", command=self.show_tasks).pack(side="right", padx=3)

        listing = tk.Frame(self.root, padx=12, pady=6)
        listing.grid(row=1, column=0, sticky="nsew")
        listing.rowconfigure(0, weight=1)
        listing.columnconfigure(0, weight=1)
        self.listbox = AppListbox(listing, activestyle="dotbox", font=("TkDefaultFont", 10))
        self.listbox.grid(row=0, column=0, sticky="nsew")
        scrollbar = tk.Scrollbar(listing, orient="vertical", command=self.listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.listbox.configure(yscrollcommand=scrollbar.set)
        self.listbox.bind("<<ListboxSelect>>", self._fill_form)

    def _selected_task(self):
        selected = self.listbox.curselection()
        if not selected:
            messagebox.showinfo("Менеджер задач", "Сначала выберите задачу.")
            return None
        return self.tasks[selected[0]]

    def _fill_form(self, _event=None):
        task = self._selected_task_silent()
        if task is None:
            return
        for entry, value in (
            (self.title_entry, task.title),
            (self.description_entry, task.description),
            (self.author_entry, task.author),
        ):
            entry.delete(0, tk.END)
            entry.insert(0, value)

    def _selected_task_silent(self):
        selected = self.listbox.curselection()
        return self.tasks[selected[0]] if selected else None

    def _form_values(self):
        title = self.title_entry.get().strip()
        if not title:
            messagebox.showwarning("Проверка данных", "Название задачи не может быть пустым.")
            return None
        return {
            "title": title,
            "description": self.description_entry.get().strip(),
            "author": self.author_entry.get().strip(),
        }

    def show_tasks(self):
        self.tasks = self.manager.get_tasks()
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            status = "✓" if task.status else "○"
            self.listbox.insert(tk.END, f"{status}  {task.title} — {task.description}  [{task.author}]")

    def add_task(self):
        values = self._form_values()
        if values is None:
            return
        self.manager.create_task(**values)
        self._clear_form()
        self.show_tasks()

    def edit_task(self):
        task = self._selected_task()
        values = self._form_values()
        if task is None or values is None:
            return
        self.manager.edit_task(task.id, **values)
        self.show_tasks()

    def delete_task(self):
        task = self._selected_task()
        if task is None:
            return
        if messagebox.askyesno("Подтверждение", f"Удалить задачу «{task.title}»?"):
            self.manager.delete_task(task.id)
            self._clear_form()
            self.show_tasks()

    def toggle_status(self):
        task = self._selected_task()
        if task is None:
            return
        self.manager.toggle_status(task.id)
        self.show_tasks()

    def _clear_form(self):
        for entry in (self.title_entry, self.description_entry, self.author_entry):
            entry.delete(0, tk.END)
